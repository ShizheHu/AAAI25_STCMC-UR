# STCMC-UR

This repository provides the implementations of STCMC-UR, presented in the paper:

## Installation
Requires Python >= 3.7 (tested on 3.8)

To install the required packages, run:
```
pip install -r requirements.txt
```
from the root directory of the repository. Anaconda (or similar) is recommended.

## Datasets
### Included dataset
The following datasets are included as files in this project:

- `Caltech-2V` (Caltech-2V)
- `Caltech-3V` (Caltech-3V)  
- `COIL20` (COIL20)
- `Event8` (Event8)
- `NUS22` (NUS22)

### Generating datasets
To generate training-ready datasets, run:
```
python -m data.make_dataset <dataset_1> <dataset_2> <...> 
```
This will export the training-ready datasets to `data/processed/<datset_name>.npz`.

Currently, the following datasets can be generated without downloading additional files:

- `Caltech-3V` (Caltech-3V)

### Datasets that require additional downloads


- `coil` (COIL-20). Download the processed files from 
[here](https://www.cs.columbia.edu/CAVE/software/softlib/coil-20.php), and place them in `data/raw/COIL`.You can find download links for other datasets online, which are omitted here.

After downloading and extracting the files, run
``` Bash
python -m data.make_dataset Caltech-2V Caltech-3V COIL20 Event8 NUS22 

```
to generate training-ready versions.

### Preparing a custom dataset for training
Create `<custom_dataset_name>.npz` in `data/processed/` with the following keys:
```
n_views: The number of views, V
labels: One-dimensional array of labels. Shape (n,)
view_0: Data for first view. Shape (n, ...)
  .
  .
  .
view_V: Data for view V. Shape (n, ...)
```
Alternatively, call
```Python
data.make_dataset.export_dataset(
    "<custom_dataset_name>",    # Name of the dataset
    views,                      # List of view-arrays
    labels                      # Label array
)
```
This will automatically export the dataset to an `.npz` file at the correct location.

Then, in the Experiment-config, set
```Python
dataset_config=Dataset("<custom_dataset_name>")
```

## Experiment configuration
Experiment configs are nested configuration objects, where the top-level config is an instance of 
`config.defaults.Experiment`. 


## Running an experiment
In the `src` directory, run:
```
python -m models.train -c <config_name> 
```
where `<config_name>` is the name of an experiment config from one of the files in `src/config/experiments/` or from 
'src/config/eamc/experiments.py' (for EAMC experiments).

### Overriding config parameters at the command-line
Parameters set in the config object can be overridden at the command line. For instance, if we want to change the 
learning rate for the E-MNIST experiment below from 0.001 to 0.0001, and the number of epochs from 100 to 200,
we can run:
```
python -m models.train -c caltech3v 
```
Note the double underscores to traverse the hierarchy of the config-object.

## Evaluating an experiment
Run the evaluation script:
```Bash
python -m models.evaluate -c <config_name> \ # Name of the experiment config
                          -t <tag> \         # The unique 8-character ID assigned to the experiment when calling models.train
                          --plot             # Optional flag to plot the representations before and after fusion.
```

