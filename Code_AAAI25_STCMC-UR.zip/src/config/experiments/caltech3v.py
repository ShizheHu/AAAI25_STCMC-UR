from config.defaults import Experiment, ObtainEvidence, Numberviews, MLP, Loss, Dataset, STCMC_UR, Optimizer
caltech3v = Experiment(
    dataset_config=Dataset(name="Caltech-3V"),
    model_config=STCMC_UR(
        backbone_configs=(
            MLP(input_size=(40,)),
            MLP(input_size=(254,)),
            MLP(input_size=(928,)),
        ),
        fusion_config=Numberviews(n_views=3),
        projector_config=None,
        cm_config=ObtainEvidence(n_clusters=7),
        loss_config=Loss(
            funcs="LC1|LC2|LC3|Alignment|LCE",
            delta=20.0
        ),
        optimizer_config=Optimizer(scheduler_step_size=50, scheduler_gamma=0.1)
    ),
)
