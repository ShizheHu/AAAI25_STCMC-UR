import torch.nn as nn
import torch as th
import torch.nn.functional as F

class ObtainEvidence(nn.Module):
    def __init__(self, input_dim, cfg):
        super().__init__()

        hidden_layers = [nn.Linear(input_dim[0], cfg.n_hidden),nn.ReLU()]
        if cfg.use_bn:
            hidden_layers.append(nn.BatchNorm1d(num_features=cfg.n_hidden))
        self.hidden = nn.Sequential(*hidden_layers)
        self.output = nn.Sequential(nn.Linear(cfg.n_hidden, cfg.n_clusters))


    def forward(self, x):

        hidden = self.hidden(x)
        output = self.output(hidden)
        e1 = F.softplus(output)

        alpha11 = e1 + 1
        S1 = th.sum(alpha11, dim=1, keepdim=True)
        b11 = e1 / S1
        u1 = 7 / S1
        e = F.softmax(output, dim=1)
        output=e*(b11+u1)

        return output, hidden