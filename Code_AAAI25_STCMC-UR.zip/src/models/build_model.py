import torch as th
import config
import helpers
from models.ObtainEvidence import ObtainEvidence
from models.STCMC_UR import STCMC_UR
from data.load import load_dataset


MODEL_CONSTRUCTORS = {
    "ObtainEvidenceModel": ObtainEvidence,
    "STCMC_UR": STCMC_UR,
}


def build_model(model_cfg):
    if model_cfg.class_name not in MODEL_CONSTRUCTORS:
        raise ValueError(f"Invalid model type: {model_cfg.type}")
    model = MODEL_CONSTRUCTORS[model_cfg.class_name](model_cfg).to(config.DEVICE, non_blocking=True)
    return model


def from_file(experiment_name=None, tag=None, run=None, ckpt="best", return_data=False, return_config=False, **kwargs):
    try:
        cfg = config.get_config_from_file(name=experiment_name, tag=tag)
    except FileNotFoundError:
        print("WARNING: Could not get pickled config.")
        cfg = config.get_config_by_name(experiment_name)

    model_dir = helpers.get_save_dir(experiment_name, identifier=tag, run=run)
    if ckpt == "best":
        model_file = "best.pt"
    else:
        model_file = f"checkpoint_{str(ckpt).zfill(4)}.pt"
    model_path = model_dir / model_file
    net = build_model(cfg.model_config)
    print(f"Loading model from {model_path}")
    net.load_state_dict(th.load(model_path, map_location=config.DEVICE))
    net.eval()
    out = [net]
    if return_data:
        dataset_kwargs = cfg.dataset_config.dict()
        for key, value in kwargs.items():
            dataset_kwargs[key] = value
        views, labels = load_dataset(to_dataset=False, **dataset_kwargs)
        out = [net, views, labels]
    if return_config:
        out.append(cfg)
    if len(out) == 1:
        out = out[0]
    return out
