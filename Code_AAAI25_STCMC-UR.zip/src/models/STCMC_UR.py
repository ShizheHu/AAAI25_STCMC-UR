import helpers
import torch.nn as nn
import torch
import torch.nn.functional as F
from lib.loss import Loss
from lib.optimizer import Optimizer
from lib.backbones import Backbones
from models.clustering_module import ObtainEvidence
from models.model_base import ModelBase
from models.token_transformer import Attention
from lib.evidence_fusion import DST

class STCMC_UR(ModelBase):
    def __init__(self, cfg):
        super().__init__()

        self.cfg = cfg
        self.hidden = self.fused = self.backbone_outputs = self.projections = None
        self.backbones = Backbones(cfg.backbone_configs)
        num_classes = 7
        num_views = 3
        self.dst_e = DST(num_views, num_classes)
        bb_sizes = self.backbones.output_sizes
        assert all([bb_sizes[0] == s  for s in bb_sizes]), f"STCMC_UR requires all backbones to have the same " \
                                                          f"output size. Got: {bb_sizes}"
        if cfg.projector_config is None:
            self.projector = nn.Identity()
        else:
            self.projector = Attention()
        self.ObtainEvidence = ObtainEvidence(input_dim=[256], cfg=cfg.cm_config)
        self.loss = Loss(cfg=cfg.loss_config)
        self.apply(helpers.he_init_weights)
        self.evidence_weights = nn.Parameter(torch.ones(num_views) / num_views, requires_grad=True)
        self.optimizer = Optimizer(cfg.optimizer_config, self.parameters())


    def forward(self, views):
        n_views = self.cfg.fusion_config.n_views
        self.backbone_outputs = self.backbones(views)
        self.projections = self.projector(torch.cat(self.backbone_outputs, dim=0))
        self.evidences = {}
        self.hiddens = dict()
        for v in range(n_views):
            self.evidences[v], self.hiddens[v] = self.ObtainEvidence(self.backbone_outputs[v])
        self.hidden = self.average_tensors(self.hiddens)
        self.evidences = self.apply_evidence_weights(self.evidences)
        self.evidence_a, self.predict, self.u= self.dst_e(self.backbone_outputs, self.evidences)
        return self.evidence_a

    def apply_evidence_weights(self, evidences):
        # Normalize weights
        weights = F.softmax(self.evidence_weights, dim=0)
        weighted_evidences = torch.stack([evidences[v] * weights[v] for v in evidences.keys()], dim=0)
        # Sum weighted evidences
        return weighted_evidences

    def average_tensors(self, tensor_dict):
        sum_tensor = None
        for tensor in tensor_dict.values():
            if isinstance(tensor, torch.Tensor):
                if sum_tensor is None:
                    sum_tensor = tensor.clone()
                else:
                    sum_tensor += tensor
            else:
                raise ValueError("All values must be Tensor")
        if sum_tensor is not None:
            return sum_tensor / len(tensor_dict)
        else:
            raise ValueError("The dictionary is empty or does not contain a valid Tensor.")