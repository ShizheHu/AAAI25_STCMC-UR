import numpy as np
import helpers
from lib.loss import Loss
from lib.optimizer import Optimizer
from lib.backbones import Backbones
from models.model_base import ModelBase
from models.clustering_module import ObtainEvidence

class ObtainEvidenceModel(ModelBase):
    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        self.backbone_output = self.output = self.hidden = None
        self.backbone = Backbones.create_backbone(cfg.backbone_config)

        self.obtainevidence_input_size = np.prod(self.backbone.output_size)
        self.obtainevidence = ObtainEvidence([self.obtainevidence_input_size], cfg.cm_config)
        self.loss = Loss(cfg.loss_config)

        # Initialize weights.
        self.apply(helpers.he_init_weights)
        # Instantiate optimizer
        self.optimizer = Optimizer(cfg.optimizer_config, self.parameters())

    def forward(self, x):
        if isinstance(x, list):
            assert len(x) == 1
            x = x[0]
        self.backbone_output = self.backbone(x).view(-1, self.obtainevidence_input_size)
        self.output, self.hidden = self.obtainevidence(self.backbone_output)
        return self.output
