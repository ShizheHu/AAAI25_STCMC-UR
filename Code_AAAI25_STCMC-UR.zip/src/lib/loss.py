import torch as th
import torch.nn as nn
import config
from lib import kernel

import torch
import torch.nn.functional as F

EPSILON = 1E-9
DEBUG_MODE = False
device = th.device("cuda" if th.cuda.is_available() else "cpu")

def triu(X):

    return th.sum(th.triu(X, diagonal=1))

def _atleast_epsilon(X, eps=EPSILON):
    return th.where(X < eps, X.new_tensor(eps), X)

def d_cs(A, K, n_clusters):

    nom = th.t(A) @ K @ A
    dnom_squared = th.unsqueeze(th.diagonal(nom), -1) @ th.unsqueeze(th.diagonal(nom), 0)

    nom = _atleast_epsilon(nom)
    dnom_squared = _atleast_epsilon(dnom_squared, eps=EPSILON**2)

    d = 2 / (n_clusters * (n_clusters - 1)) * triu(nom / th.sqrt(dnom_squared))
    return d

class LossTerm:
    required_tensors = []

    def __init__(self, *args, **kwargs):
        pass

    def __call__(self, net, cfg, extra):
        raise NotImplementedError()

class LC1(LossTerm):
    required_tensors = ["hidden_kernel"]
    def __call__(self, net, cfg, extra):
        return (d_cs(net.evidence_a, extra["hidden_kernel"], cfg.n_clusters))

class LC2(LossTerm):
    def __call__(self, net, cfg, extra):
        n = net.evidence_a.size(0)
        return (2 / (n * (n - 1)) * triu(net.evidence_a @ th.t(net.evidence_a)))

class LC3(LossTerm):
    required_tensors = ["hidden_kernel"]

    def __init__(self, cfg):
        super().__init__()
        self.eye = th.eye(cfg.n_clusters, device=config.DEVICE)

    def __call__(self, net, cfg, extra):
        m = th.exp(-kernel.cdist(net.evidence_a, self.eye))
        return (d_cs(m, extra["hidden_kernel"], cfg.n_clusters))

class Alignment(LossTerm):
    large_num = 1e9

    def __init__(self, cfg):

        super().__init__()
        # Select which implementation to use
        if cfg.negative_samples_ratio == -1:
            self._loss_func = self._loss_without_negative_sampling
        else:
            self.eye = th.eye(cfg.n_clusters, device=config.DEVICE)
            self._loss_func = self._loss_with_negative_sampling

        # Set similarity function
        if cfg.contrastive_similarity == "cos":
            self.similarity_func = self._cosine_similarity
        elif cfg.contrastive_similarity == "gauss":
            self.similarity_func = kernel.vector_kernel
        else:
            raise RuntimeError(f"Invalid contrastive similarity: {cfg.contrastive_similarity}")

    @staticmethod
    def _norm(mat):
        return th.nn.functional.normalize(mat, p=2, dim=1)

    @staticmethod
    def get_weight(net):
        w = th.min(th.nn.functional.softmax(net.fusion.weights.detach(), dim=0))
        return w

    @classmethod
    def _normalized_projections(cls, net):
        n = net.projections.size(0) // 2
        h1, h2 = net.projections[:n], net.projections[n:]
        h2 = cls._norm(h2)
        h1 = cls._norm(h1)
        return n, h1, h2

    @classmethod
    def _cosine_similarity(cls, projections):
        h = cls._norm(projections)
        return h @ h.t()

    def _draw_negative_samples(self, net, cfg, v, pos_indices):
        cat = net.evidence_a.detach().argmax(dim=1)
        cat = th.cat(v * [cat], dim=0)
        a = self.eye[cat]
        for i in range(net.evidence_a.size(0)):
            if net.u[i] > 0.91:
                a[i, :] = 0
                a[i + 100, :] = 0
                a[i + 200, :] = 0

        weights = (1 - a)[:, cat[[pos_indices]]].T
        if torch.sum(weights) <= 0:
            return th.LongTensor([]).to(net.evidence_a.device)
        n_negative_samples = int(cfg.negative_samples_ratio * cat.size(0))
        negative_sample_indices = th.multinomial(weights, n_negative_samples, replacement=True)
        if DEBUG_MODE:
            self._check_negative_samples_valid(cat, pos_indices, negative_sample_indices)
        return negative_sample_indices

    @staticmethod
    def _check_negative_samples_valid(cat, pos_indices, neg_indices):
        pos_cats = cat[pos_indices].view(-1, 1)
        neg_cats = cat[neg_indices]
        assert (pos_cats != neg_cats).detach().cpu().numpy().all()

    @staticmethod
    def _get_positive_samples(logits, v, n):
        diagonals = []
        inds = []
        for i in range(1, v):
            diagonal_offset = i * n
            diag_length = (v - i) * n
            _upper = th.diagonal(logits, offset=diagonal_offset)
            _lower = th.diagonal(logits, offset=-1 * diagonal_offset)
            _upper_inds = th.arange(0, diag_length)
            _lower_inds = th.arange(i * n, v * n)
            if DEBUG_MODE:
                assert _upper.size() == _lower.size() == _upper_inds.size() == _lower_inds.size() == (diag_length,)
            diagonals += [_upper, _lower]
            inds += [_upper_inds, _lower_inds]

        pos = th.cat(diagonals, dim=0)
        pos_inds = th.cat(inds, dim=0)
        return pos, pos_inds

    def _loss_with_negative_sampling(self, net, cfg, extra):
        n = net.evidence_a.size(0)
        v = len(net.backbone_outputs)
        logits = self.similarity_func(net.projections) / cfg.tau

        pos, pos_inds = self._get_positive_samples(logits, v, n)
        neg_inds = self._draw_negative_samples(net, cfg, v, pos_inds)
        if neg_inds.numel() == 0:
            return torch.tensor(0.0).to(net.evidence_a.device)
        neg = logits[pos_inds.view(-1, 1), neg_inds]

        inputs = th.cat((pos.view(-1, 1), neg), dim=1)
        labels = th.zeros(v * (v - 1) * n, device=config.DEVICE, dtype=th.long)
        loss0 = th.nn.functional.cross_entropy(inputs, labels)
        loss = loss0
        loss *= cfg.c1
        return cfg.delta * loss

    def _loss_without_negative_sampling(self, net, cfg, extra):
        assert len(net.backbone_outputs) == 2, "Contrastive loss without negative sampling only supports 2 views."
        n, h1, h2 = self._normalized_projections(net)

        labels = th.arange(0, n, device=config.DEVICE, dtype=th.long)
        masks = th.eye(n, device=config.DEVICE)

        logits_aa = ((h1 @ h1.t()) / cfg.tau) - masks * self.large_num
        logits_bb = ((h2 @ h2.t()) / cfg.tau) - masks * self.large_num

        logits_ab = (h1 @ h2.t()) / cfg.tau
        logits_ba = (h2 @ h1.t()) / cfg.tau

        loss_a = th.nn.functional.cross_entropy(th.cat((logits_ab, logits_aa), dim=1), labels)
        loss_b = th.nn.functional.cross_entropy(th.cat((logits_ba, logits_bb), dim=1), labels)

        loss = (loss_a + loss_b)

        if cfg.adaptive_contrastive_weight:
            loss *= self.get_weight(net)
        return cfg.delta * loss

    def __call__(self, net, cfg, extra):
        return self._loss_func(net, cfg, extra)

'''
@inproceedings{xu2024reliable,
  title={Reliable conflictive multi-view learning},
  author={Xu, Cai and Si, Jiajun and Guan, Ziyu and Zhao, Wei and Wu, Yue and Gao, Xiyue},
  booktitle={Proceedings of the AAAI Conference on Artificial Intelligence},
  volume={38},
  number={14},
  pages={16129--16137},
  year={2024}
}'''
class LCE(LossTerm):
    def __call__(self, net, cfg, extra):
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        return (self.get_dc_loss(net.evidences,device)*cfg.c2)
    def get_dc_loss(self,evidences, device):
        num_views = len(evidences)
        batch_size, num_classes = evidences[0].shape[0], evidences[0].shape[1]
        p = torch.zeros((num_views, batch_size, num_classes)).to(device)
        u = torch.zeros((num_views, batch_size)).to(device)
        for v in range(num_views):
            alpha = evidences[v] + 1
            S = torch.sum(alpha, dim=1, keepdim=True)
            p[v] = alpha / S
            u[v] = torch.squeeze(num_classes / S)
        dc_sum = 0
        for i in range(num_views):
            pd = torch.sum(torch.abs(p - p[i]) / 2, dim=2) / (num_views - 1)  # (num_views, batch_size)
            cc = (1 - u[i]) * (1 - u)  # (num_views, batch_size)
            dc = pd * cc
            dc_sum = dc_sum + torch.sum(dc, dim=0)
        dc_sum = torch.mean(dc_sum)
        return dc_sum
    def edl_loss(self,func, y, alpha, epoch_num, num_classes, annealing_step, device, useKL=True):
        y = y.to(device)
        alpha = alpha.to(device)
        S = torch.sum(alpha, dim=1, keepdim=True)

        A = torch.sum(y * (func(S) - func(alpha)), dim=1, keepdim=True)

        if not useKL:
            return A

        annealing_coef = torch.min(
            torch.tensor(1.0, dtype=torch.float32),
            torch.tensor(epoch_num / annealing_step, dtype=torch.float32),
        )

        kl_alpha = (alpha - 1) * (1 - y) + 1
        kl_div = annealing_coef * self.kl_divergence(kl_alpha, num_classes, device=device)
        return A + kl_div

    def kl_divergence(self,alpha, num_classes, device):
        ones = torch.ones([1, num_classes], dtype=torch.float32, device=device)
        sum_alpha = torch.sum(alpha, dim=1, keepdim=True)
        first_term = (
                torch.lgamma(sum_alpha)
                - torch.lgamma(alpha).sum(dim=1, keepdim=True)
                + torch.lgamma(ones).sum(dim=1, keepdim=True)
                - torch.lgamma(ones.sum(dim=1, keepdim=True))
        )
        second_term = (
            (alpha - ones)
            .mul(torch.digamma(alpha) - torch.digamma(sum_alpha))
            .sum(dim=1, keepdim=True)
        )
        kl = first_term + second_term
        return kl

    def edl_digamma_loss(self,alpha, target, epoch_num, num_classes, annealing_step, device):
        loss = self.edl_loss(torch.digamma, target, alpha, epoch_num, num_classes, annealing_step, device)
        return torch.mean(loss)

    def get_loss(self,evidences, evidence_a, target, epoch_num, num_classes, annealing_step, device):
        target = F.one_hot(target, num_classes)
        alpha_a = evidence_a + 1
        loss_acc = self.edl_digamma_loss(alpha_a, target, epoch_num, num_classes, annealing_step, device)
        for v in range(len(evidences)):
            alpha = evidences[v] + 1
            loss_acc += self.edl_digamma_loss(alpha, target, epoch_num, num_classes, annealing_step, device)
        loss_acc = loss_acc / (len(evidences) + 1)
        return loss_acc

def hidden_kernel(net, cfg):

    return kernel.vector_kernel(net.hidden, cfg.rel_sigma)

class Loss(nn.Module):
    TERM_CLASSES = {
        "LC1": LC1,
        "LC2": LC2,
        "LC3": LC3,
        "Alignment": Alignment,
        "LCE": LCE,
    }
    EXTRA_FUNCS = {
        "hidden_kernel": hidden_kernel,
    }

    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        self.names = cfg.funcs.split("|")
        self.weights = cfg.weights if cfg.weights is not None else len(self.names) * [1]
        self.terms = []
        for term_name in self.names:
            self.terms.append(self.TERM_CLASSES[term_name](cfg))
        self.required_extras_names = list(set(sum([t.required_tensors for t in self.terms], [])))


    def forward(self, net, ignore_in_total=tuple()):
        extra = {name: self.EXTRA_FUNCS[name](net, self.cfg) for name in self.required_extras_names}
        loss_values = {}
        for name, term, weight in zip(self.names, self.terms, self.weights):
            value = term(net, self.cfg, extra)
            if isinstance(value, dict):
                for key, _value in value.items():
                    loss_values[f"{name}/{key}"] = weight * _value
            else:
                loss_values[name] = weight * value

        loss_values["tot"] = sum([loss_values[k] for k in loss_values.keys() if k not in ignore_in_total])
        return loss_values