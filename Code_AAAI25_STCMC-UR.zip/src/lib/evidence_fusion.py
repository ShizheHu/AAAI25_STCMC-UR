import torch
import torch.nn as nn



'''@article{han2022trusted,
  title={Trusted multi-view classification with dynamic evidential fusion},
  author={Han, Zongbo and Zhang, Changqing and Fu, Huazhu and Zhou, Joey Tianyi},
  journal={IEEE transactions on pattern analysis and machine intelligence},
  volume={45},
  number={2},
  pages={2551--2566},
  year={2022},
  publisher={IEEE}
}'''
class DST(nn.Module):
    def __init__(self, num_views, n_clusters):
        super(DST, self).__init__()
        self.num_views = num_views
        self.n_clusters = n_clusters

    def DS_Combin(self, alpha):
        def DS_Combin_two(alpha1, alpha2):
            alpha = dict()
            alpha[0], alpha[1] = alpha1, alpha2
            b, S, E, u = dict(), dict(), dict(), dict()
            for v in range(2):
                S[v] = torch.sum(alpha[v], dim=1, keepdim=True)
                E[v] = alpha[v]-1
                b[v] = E[v]/(S[v].expand(E[v].shape))
                u[v] = self.n_clusters/S[v]

            # b^0 @ b^(0+1)
            bb = torch.bmm(b[0].view(-1, self.n_clusters, 1), b[1].view(-1, 1, self.n_clusters))
            # b^0 * u^1
            uv1_expand = u[1].expand(b[0].shape)
            bu = torch.mul(b[0], uv1_expand)
            # b^1 * u^0
            uv_expand = u[0].expand(b[0].shape)
            ub = torch.mul(b[1], uv_expand)
            # calculate C
            bb_sum = torch.sum(bb, dim=(1, 2), out=None)
            bb_diag = torch.diagonal(bb, dim1=-2, dim2=-1).sum(-1)
            C = bb_sum - bb_diag

            # calculate b^a
            b_a = (torch.mul(b[0], b[1]) + bu + ub)/((1-C).view(-1, 1).expand(b[0].shape))
            # calculate u^a
            u_a = torch.mul(u[0], u[1])/((1-C).view(-1, 1).expand(u[0].shape))


            # calculate new S
            S_a = self.n_clusters / u_a
            # calculate new e_k
            e_a = torch.mul(b_a, S_a.expand(b_a.shape))
            alpha_a = e_a + 1
            return alpha_a, u_a

        for v in range(len(alpha)-1):
            if v==0:
                alpha_a ,u= DS_Combin_two(alpha[0], alpha[1])
            else:
                alpha_a ,u= DS_Combin_two(alpha_a, alpha[v+1])
        return alpha_a, u

    def forward(self, X,evidences):
        # get evidence
        alpha = dict()
        for v_num in range(len(X)):
            alpha[v_num] = evidences[v_num] + 1
        alpha_a , u= self.DS_Combin(alpha)
        evidence_a = alpha_a - 1
        _, predicted = torch.max(evidence_a.data, 1)

        return evidence_a,predicted, u
